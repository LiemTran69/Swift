<?php
mysql_connect("localhost", "root", "");
mysql_select_db("WebServices_150317");
mysql_query(" SET NAMES 'utf8' ");

class USERS{
  public $ID;
  public $HOTEN;
  public $EMAIL;

  function USERS($id, $hoten, $email){
    $this->ID = $id;
    $this->HOTEN = $hoten;
    $this->EMAIL = $email;
  }

}

?>
