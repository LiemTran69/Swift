
import Foundation

class Number{
    
    var TEN:String
    var HINH:String
    
    init(ten:String, hinh:String) {
        self.TEN = ten
        self.HINH = hinh
    }
}
